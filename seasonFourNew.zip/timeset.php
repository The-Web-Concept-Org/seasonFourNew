<?php
echo date_default_timezone_set('Asia/Karachi');

echo  date('d-m-y h:i A');
?>